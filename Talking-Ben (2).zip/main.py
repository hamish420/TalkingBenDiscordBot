import random

dialougue = ["Yes","No","Laughs","oeughh"]

print(random.choice(dialougue))